import { Component, OnInit } from '@angular/core';
import { Contact } from '../contact';
import { ContactService } from '../contact.service';
import { Location } from '@angular/common';
import { HomePageComponent } from '../home-page/home-page.component';
import { Observable, interval, Subscription } from 'rxjs';

@Component({
  selector: 'app-add-contact',
  templateUrl: './add-contact.component.html',
  styleUrls: ['./add-contact.component.css']
})
export class AddContactComponent implements OnInit {
  private updateSubscription: Subscription;
  con : Contact = new Contact();
  
  constructor(private service: ContactService,
              private location: Location) { }

  ngOnInit(): void {
  }

  public addContact() {
    //alert(JSON.stringify(this.carPart));
    this.service.addContact(this.con).subscribe(data => {
     
     // alert(JSON.stringify(data));
     
    })
    let homeobj = new HomePageComponent(this.service);
    this.updateSubscription = interval(1000).subscribe(
      (val) => { homeobj.ngOnInit()    });
      homeobj.viewallContacts();
      console.log("addcontact called")
      this.goback();
  }
  goback(){
    this.location.back();
  }
}
