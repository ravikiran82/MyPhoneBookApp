import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Image;
import java.awt.TextArea;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
                              
class MyNotepad extends Frame implements ActionListener, WindowListener 
{
    TextArea dataToType = new TextArea(10,40);
    TextField filenameToType = new TextField(20);
    Icon ic = new ImageIcon();
    JButton saveToClick = new JButton("save",ic);
    Button clearToClick = new Button("Clear Data");
    MyNotepad()
    {
        super.setSize(400,400);
        super.setLocation(100,100);
        super.setLayout(new FlowLayout());
        super.add(dataToType);
        super.add(filenameToType);
        super.add(saveToClick);
        super.add(clearToClick);
        saveToClick.addActionListener(this);
        clearToClick.addActionListener(this);
        this.addWindowListener(this);
    }
  
    public void actionPerformed(ActionEvent ae)
    {    
    	if(ae.getSource()==saveToClick)
        {
            System.out.println("save is clicked.");
            try 
            {
                System.out.println("Trying to make a file.");
                FileOutputStream fout = new FileOutputStream("d:\\Core Java\\myjava\\"+filenameToType.getText());
                System.out.println("file is created.");
                String stringDataHere = dataToType.getText();
                byte byteDataHere[] = stringDataHere.getBytes();
                fout.write(byteDataHere); 
                System.out.println("Trying to close the file.");
                fout.close();
                System.out.println("file is closed.");
            }
            catch (FileNotFoundException e) {        
                System.out.println("Problem: "+e);
            }
            catch (IOException e) {                
                System.out.println("Problem: "+e);
            }
            catch(RuntimeException e) {                
                System.out.println("Problem: "+e);
            }
            catch(Exception e) {

                System.out.println("Problem: "+e);
            }
            catch(Throwable t) {
                System.out.println("Problem: "+t);
            }
        }
        else if(ae.getSource()==clearToClick) 
        {
            System.out.println("CLEAR is clicked.");
            dataToType.setText("\r");
            filenameToType.setText("\r");
        } 
    }
    @Override
    public void windowOpened(WindowEvent e) {
        System.out.println("Window opened..");
        
    }
    @Override
    public void windowClosing(WindowEvent e) {
        // TODO Auto-generated method stub
        System.out.println("Window closing..");
        windowClosed(e); 
    }
    @Override
    public void windowClosed(WindowEvent e) {
        // TODO Auto-generated method stub
        System.out.println("Window closed..");
        setVisible(false); 
        System.exit(0); 
    }
    @Override
    public void windowIconified(WindowEvent e) {
        // TODO Auto-generated method stub
        System.out.println("Window minimized..");
    }
    @Override
    public void windowDeiconified(WindowEvent e) {
        // TODO Auto-generated method stub
        System.out.println("Window restored..");
    }
    @Override
    public void windowActivated(WindowEvent e) {
        // TODO Auto-generated method stub
        System.out.println("Window activated..");
    }
    @Override
    public void windowDeactivated(WindowEvent e) {
        // TODO Auto-generated method stub
        System.out.println("Window de-activated..");
    }

}
public class FileWriteTest2 {
    public static void main(String[] args) {
        System.out.println("Begin main..");
            MyNotepad n = new MyNotepad();
            n.setVisible(true);
        System.out.println("End of main..");
    }
}
