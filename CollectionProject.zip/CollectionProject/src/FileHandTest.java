import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class FileHandTest {

	public static void main(String[] args) {
		System.out.println("Begin Main");
		try
		{
			System.out.println("trying to open a file");
			FileInputStream fin = new FileInputStream("D:\\Core Java\\myjava\\ravi.txt");
			byte b = (byte) fin.read();
			while(b!=-1)
			{
				System.out.print((char)b);
				b = (byte) fin.read();
				Thread.sleep(10);
						
			}
			System.out.println("Trying to close the file");
			fin.close();
			System.out.println("file is closed.");
		}
		catch(FileNotFoundException e) {
			System.out.println("Problem : "+e);
		}
		catch(IOException e) {
			System.out.println("Problem : "+e);
		}
		catch(RuntimeException e) {                
            System.out.println("Problem: "+e);
        }
        catch(Exception e) {                    
            System.out.println("Problem: "+e);
        }
        catch(Throwable t) {
            System.out.println("Problem: "+t);
        }
		System.out.println("End main.");
	}

}
