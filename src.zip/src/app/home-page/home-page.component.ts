import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { AddContactComponent } from '../add-contact/add-contact.component';
import { Contact } from '../contact';
import { ContactService } from '../contact.service';
import { Observable, interval, Subscription } from 'rxjs';


@Component({
  selector: 'app-home-page',
  templateUrl: './home-page.component.html',
  styleUrls: ['./home-page.component.css']
})
export class HomePageComponent implements OnInit {

 
  private updateSubscription: Subscription;

  constructor(private service: ContactService,
              ) { }

  nametosearch: string = '';
  contacts: Contact[];
  tempCont: Contact[];
  
  //data=[{firstName:"RAVI", lastName:"KIRAN", phoneNumber:"999999999"},{firstName:"RAJESH", lastName:"B", phoneNumber:"8888888"},{firstName:"JHON", lastName:"AB", phoneNumber:"111111111"}];

  ngOnInit(): void {

    this.viewallContacts()
  }
  public viewallContacts(){
    this.service.fetchAllContacts().subscribe((data:Contact[]) =>{
      this.contacts=data;
      this.tempCont=data;
      
    })
    
  }
  refresh(){
    this.viewallContacts()
  }

  updateConArray(){
    if(this.nametosearch == ''){
      console.log('it is NULL : '+this.nametosearch);
      this.tempCont = this.contacts;
    }

    else{
      console.log('it is not NULL : '+this.nametosearch);
      this.tempCont = this.contacts.filter(d=> (d.firstName == this.nametosearch));
      console.log('tempCont length : '+this.tempCont.length);
      console.log('contacts length : '+this.contacts.length);
    }
    

  }
  deleteContact(nametodelete: string){
    this.service.deleteContact(nametodelete).subscribe((data: Contact) => {   })
    this.updateSubscription = interval(1000).subscribe(
      (val) => { this.ngOnInit()    });
  }
 
  

}
