import java.util.ArrayList;
import java.util.Iterator;
public class ArrayTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

        TreeSet myScore = new TreeSet();
        System.out.println("ArrayList container is created..");
        
            
        System.out.println("Length : "+myScore.size());
        
        
        myScore.add(28);
        myScore.add(1);
        myScore.add('z');
        myScore.add("ravi");
        myScore.add(45.00);
        
        
        
        System.out.println("Length : "+myScore.size());
       


        Iterator myIter = myScore.iterator();
        while(myIter.hasNext())
        {
            Object o = myIter.next();
            System.out.println("Object : "+o);
        }
    }
}
