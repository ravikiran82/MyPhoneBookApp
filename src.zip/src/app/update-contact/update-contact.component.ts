import { Component, OnInit } from '@angular/core';
import { interval, Subscription } from 'rxjs';
import { Contact } from '../contact';
import { ContactService } from '../contact.service';
import { HomePageComponent } from '../home-page/home-page.component';
import { Location } from '@angular/common';

@Component({
  selector: 'app-update-contact',
  templateUrl: './update-contact.component.html',
  styleUrls: ['./update-contact.component.css']
})
export class UpdateContactComponent implements OnInit {
  
  con : Contact = new Contact();
  private updateSubscription: Subscription;
  constructor(private service: ContactService,
              private location: Location) { }

  ngOnInit(): void {
    
  }
   

  updateContact(){
    
    this.service.updateContact(this.con).subscribe(data =>{
      console.log("Updated the data")
    })
    let homeobj = new HomePageComponent(this.service);
    this.updateSubscription = interval(1000).subscribe(
      (val) => { homeobj.ngOnInit()    });
      homeobj.viewallContacts();
      console.log("addcontact called")
      this.goback();
  }
  goback(){
    this.location.back()
  }

}
