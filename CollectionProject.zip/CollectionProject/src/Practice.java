
public class Practice {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//M m1= new M();
		//m1.a(); m1.b(); m1.c(); m1.d(); m1.e(); m1.f();
		int a = 16;
		if(a==10){System.out.println("10");}
		else if (a>10); 
	}
}
interface A{  
void a();  
void b();  
void c();  
void d();
void e();
}  
  
abstract class B implements A{  
	public void e() {System.out.println("I am e");}
	void f() {System.out.println("I am f");}

}  
  
class M extends B{  
public void a(){System.out.println("I am a");}  
public void b(){System.out.println("I am b");}  
public void d(){System.out.println("I am d");}  
public void c(){System.out.println("I am c");}  
public void e() {System.out.println("I am e");}
}  