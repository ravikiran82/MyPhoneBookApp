import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class FileWriteTest {

	public static void main(String[] args) {
		System.out.println("Begin Main");
		try
		{
			System.out.println("trying to make a file");
			FileOutputStream fout = new FileOutputStream("D:\\Core Java\\myjava\\kiran.txt");
			System.out.println("Filse is created");
			String stringDataHere = "Hello kiran how is the program";
			byte byteDataHere[]=stringDataHere.getBytes();
			
			fout.write(byteDataHere);
			System.out.println("Trying to close the file");
			fout.close();
			System.out.println("file is closed.");
		}
		catch(FileNotFoundException e) {
			System.out.println("Problem : "+e);
		}
		catch(IOException e) {
			System.out.println("Problem : "+e);
		}
		catch(RuntimeException e) {                
            System.out.println("Problem: "+e);
        }
        catch(Exception e) {                    
            System.out.println("Problem: "+e);
        }
        catch(Throwable t) {
            System.out.println("Problem: "+t);
        }
		System.out.println("End main.");
	}

}
