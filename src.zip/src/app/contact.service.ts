import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Contact } from './contact';

@Injectable({
  providedIn: 'root'
})
export class ContactService {

  constructor(private http: HttpClient) { }

  fetchAllContacts(){
    let url = 'http://localhost:8090/ContactRestProjec/rest/contacts/';
    return this.http.get(url);
  }
  addContact(contact: Contact){
    let url = 'http://localhost:8090/ContactRestProjec/rest/contacts/create';
    return this.http.post(url, contact);
    
  }
  deleteContact(firstName: string){
    let url = 'http://localhost:8090/ContactRestProjec/rest/contacts/delete/';
    return this.http.delete(url+firstName);
    
  }

  updateContact(contact: Contact){
    let url = 'http://localhost:8090/ContactRestProjec/rest/contacts/update';
    return this.http.put(url, contact);

  }
}