import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddContactComponent } from './add-contact/add-contact.component';
import { HomePageComponent } from './home-page/home-page.component';
import { UpdateContactComponent } from './update-contact/update-contact.component';

const routes: Routes = [
{path: 'addcontact', component: AddContactComponent},
{path: 'homepage', component: HomePageComponent},
{path: 'update', component: UpdateContactComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
